void load_flag_from_pgm(char **flag, int imax, int jmax, char *filename);
void init_flag(char **flag, int imax, int jmax, float delx, float dely,
    int *ibound);
